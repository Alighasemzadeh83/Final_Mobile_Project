import Foundation
import Combine

@MainActor
final class NotesViewModel: ObservableObject {
    @Published var items: [Note] = []
    @Published var query: String = ""
    @Published var isLoading = false
    @Published var page = 1
    @Published var total = 0
    @Published var isGuest = false

    private var bag = Set<AnyCancellable>()

    init() {
        $query
            .debounce(for: .milliseconds(350), scheduler: RunLoop.main)
            .sink { [weak self] _ in Task { await self?.search() } }
            .store(in: &bag)
    }

    func loadFirstPage() async {
        isGuest = (TokenStore.shared.access == nil && TokenStore.shared.refresh == nil)
        if isGuest {
            // map GuestNote to Note shape
            let local = GuestNoteStore.shared.all().map { g in
                Note(id: g.id, title: g.title, description: g.description,
                     created_at: ISO8601DateFormatter().string(from: g.created),
                     updated_at: ISO8601DateFormatter().string(from: g.updated))
            }
            self.items = local
            self.total = local.count
        } else {
            await fetch(page: 1)
        }
    }

    func fetch(page: Int) async {
        guard !isGuest else { return }
        isLoading = true
        defer { isLoading = false }
        do {
            let resp = try await NotesAPI.list(page: page, pageSize: 20)
            self.page = page
            self.total = resp.count
            if page == 1 { self.items = resp.results } else { self.items += resp.results }
        } catch { print("fetch error", error) }
    }

    func search() async {
        let q = query.trimmingCharacters(in: .whitespacesAndNewlines)
        if q.isEmpty { await loadFirstPage(); return }
        if isGuest {
            let local = GuestNoteStore.shared.all().filter { $0.title.localizedCaseInsensitiveContains(q) || $0.description.localizedCaseInsensitiveContains(q) }
            self.items = local.map { g in
                Note(id: g.id, title: g.title, description: g.description,
                     created_at: ISO8601DateFormatter().string(from: g.created),
                     updated_at: ISO8601DateFormatter().string(from: g.updated))
            }
            self.total = items.count
        } else {
            do { let resp = try await NotesAPI.filter(title: q, description: q, page: 1, pageSize: 40); self.items = resp.results; self.total = resp.count } catch {}
        }
    }
}
