import SwiftUI

struct GettingStartedScreen: View {
    @EnvironmentObject var app: AppState
    @State private var showLogin = false
    @State private var showRegister = false

    var body: some View {
        NavigationStack {
            VStack(spacing: 16) {
                Text("Welcome to SimpleNote!").font(.largeTitle.bold())
                Button("Login") { showLogin = true }
                    .buttonStyle(.borderedProminent)
                Button("Continue as Guest") { app.logout() }
            }
            .padding()
            .navigationDestination(isPresented: $showLogin) { LoginScreen() }
            .navigationDestination(isPresented: $showRegister) { RegisterScreen() }
        }
    }
}

struct LoginScreen: View {
    @EnvironmentObject var app: AppState
    @State private var username = ""
    @State private var password = ""
    @State private var message = ""
    @State private var busy = false

    var body: some View {
        Form {
            Section("Login") {
                TextField("Username", text: $username).textInputAutocapitalization(.never)
                SecureField("Password", text: $password)
                if !message.isEmpty { Text(message).foregroundStyle(.red) }
                Button(busy ? "Logging in..." : "Login") {
                    Task { await doLogin() }
                }.disabled(busy)
            }
        }
    }

    func doLogin() async {
        busy = true; defer { busy = false }
        do {
            let resp = try await AuthAPI.login(username: username, password: password)
            app.onLogin(access: resp.access, refresh: resp.refresh)
            // push guest notes to server
            let guest = GuestNoteStore.shared.all()
            for g in guest { _ = try? await NotesAPI.create(NoteRequest(title: g.title, description: g.description)) }
            GuestNoteStore.shared.clear()
        } catch { message = "Login failed" }
    }
}

struct NotesScreen: View {
    @EnvironmentObject var app: AppState
    @StateObject var vm = NotesViewModel()
    @State private var showCreate = false
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                HStack { Image(systemName: "magnifyingglass"); TextField("Search...", text: $vm.query).textFieldStyle(.roundedBorder) }.padding()
                ScrollView {
                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                        ForEach(vm.items) { n in
                            NoteCard(note: n)
                        }
                    }.padding(.horizontal)
                }
            }
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    if app.isLoggedIn { NavigationLink("Settings") { ProfileScreen() } }
                }
                ToolbarItem(placement: .status) {
                    Button { showCreate = true } label: { Image(systemName: "plus.circle.fill").font(.title) }
                }
            }
            .navigationTitle("Notes")
            .task { await vm.loadFirstPage() }
            .sheet(isPresented: $showCreate) { NoteEditScreen() }
        }
    }
}

struct NoteCard: View {
    let note: Note
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(note.title).font(.headline)
            Text(note.description).font(.subheadline)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(colorFor(id: note.id))
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }
    func colorFor(id: Int) -> Color {
        let colors: [Color] = [Color(hex: 0xFFF9C4), Color(hex: 0xFFECB3), Color(hex: 0xFFF3E0), Color(hex: 0xE1F5FE), Color(hex: 0xE8F5E9)]
        return colors[abs(id) % colors.count]
    }
}

extension Color { init(hex: UInt32) { self.init(red: Double((hex>>16)&0xFF)/255, green: Double((hex>>8)&0xFF)/255, blue: Double(hex&0xFF)/255) } }

struct ProfileScreen: View { @EnvironmentObject var app: AppState
    var body: some View { Form { Button("Log Out", role: .destructive) { app.logout() } } .navigationTitle("Settings") }
}

struct NoteEditScreen: View { @Environment(\.dismiss) var dismiss
    @State private var title = ""; @State private var desc = ""; @State private var busy = false
    var body: some View {
        Form { Section { TextField("Title", text: $title); TextField("Description", text: $desc, axis: .vertical).lineLimit(4...10) }
            Button(busy ? "Saving..." : "Save") { Task { await save() } }.disabled(busy) }
            .navigationTitle("Create Note")
    }
    func save() async {
        busy = true; defer { busy = false }
        if TokenStore.shared.access == nil && TokenStore.shared.refresh == nil {
            _ = GuestNoteStore.shared.create(title: title, desc: desc)
        } else {
            _ = try? await NotesAPI.create(NoteRequest(title: title, description: desc))
        }
        dismiss()
    }
}
