import Foundation

final class TokenStore {
    static let shared = TokenStore()
    private init() {}

    private let accessKey = "access_token"
    private let refreshKey = "refresh_token"

    var access: String? { UserDefaults.standard.string(forKey: accessKey) }
    var refresh: String? { UserDefaults.standard.string(forKey: refreshKey) }

    func save(access: String?, refresh: String?) {
        let d = UserDefaults.standard
        d.setValue(access, forKey: accessKey)
        d.setValue(refresh, forKey: refreshKey)
    }

    func clear() {
        let d = UserDefaults.standard
        d.removeObject(forKey: accessKey)
        d.removeObject(forKey: refreshKey)
    }
}
