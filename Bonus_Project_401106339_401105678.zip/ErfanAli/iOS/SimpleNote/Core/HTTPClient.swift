import Foundation

enum APIError: Error { case invalidURL, http(Int), decoding, noData }

actor TokenManager {
    static let shared = TokenManager()
    private init() {}
    private var isRefreshing = false

    func withValidAccessToken(_ perform: @escaping (String?) -> Void) async {
        perform(TokenStore.shared.access)
    }

    func refreshIfNeeded() async -> String? {
        if isRefreshing { return TokenStore.shared.access }
        guard let refresh = TokenStore.shared.refresh else { return nil }
        isRefreshing = true
        defer { isRefreshing = false }
        do {
            let newAccess = try await AuthAPI.refreshToken(refresh: refresh)
            TokenStore.shared.save(access: newAccess, refresh: refresh)
            return newAccess
        } catch { return nil }
    }
}

struct HTTPClient {
    static var baseURL = URL(string: "http://127.0.0.1:8000")!

    static func request(_ path: String,
                        method: String = "GET",
                        query: [URLQueryItem] = [],
                        body: Data? = nil,
                        authorized: Bool = true) async throws -> (Data, HTTPURLResponse) {
        var comps = URLComponents(url: baseURL.appendingPathComponent(path), resolvingAgainstBaseURL: false)!
        if !query.isEmpty { comps.queryItems = query }
        guard let url = comps.url else { throw APIError.invalidURL }
        var req = URLRequest(url: url)
        req.httpMethod = method
        if let body { req.httpBody = body; req.setValue("application/json", forHTTPHeaderField: "Content-Type") }
        if authorized, let token = TokenStore.shared.access { req.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization") }
        let (data, resp) = try await URLSession.shared.data(for: req)
        guard let http = resp as? HTTPURLResponse else { throw APIError.noData }
        if http.statusCode == 401, authorized {
            if let newAccess = await TokenManager.shared.refreshIfNeeded() {
                var retry = req
                retry.setValue("Bearer \(newAccess)", forHTTPHeaderField: "Authorization")
                let (rd, rr) = try await URLSession.shared.data(for: retry)
                return (rd, rr as! HTTPURLResponse)
            }
        }
        return (data, http)
    }

    static func decode<T: Decodable>(_ data: Data) throws -> T {
        let dec = JSONDecoder()
        dec.keyDecodingStrategy = .convertFromSnakeCase
        do { return try dec.decode(T.self, from: data) } catch { throw APIError.decoding }
    }
}
