import Foundation

struct GuestNote: Codable, Identifiable { var id: Int; var title: String; var description: String; var created: Date; var updated: Date }

final class GuestNoteStore {
    static let shared = GuestNoteStore()
    private init() { load() }

    private let url: URL = {
        let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        return dir.appendingPathComponent("guest_notes.json")
    }()

    private(set) var notes: [GuestNote] = []

    private func save() { try? JSONEncoder().encode(notes).write(to: url, options: .atomic) }
    private func load() {
        guard let data = try? Data(contentsOf: url) else { notes = []; return }
        notes = (try? JSONDecoder().decode([GuestNote].self, from: data)) ?? []
    }

    func all() -> [GuestNote] { notes.sorted(by: { $0.updated > $1.updated }) }

    func create(title: String, desc: String) -> GuestNote {
        let newId = (notes.map{$0.id}.max() ?? 0) + 1
        let n = GuestNote(id: newId, title: title, description: desc, created: Date(), updated: Date())
        notes.append(n); save(); return n
    }

    func update(id: Int, title: String, desc: String) -> GuestNote? {
        guard let idx = notes.firstIndex(where: {$0.id == id}) else { return nil }
        notes[idx].title = title; notes[idx].description = desc; notes[idx].updated = Date(); save(); return notes[idx]
    }

    func delete(id: Int) { notes.removeAll{ $0.id == id }; save() }
    func clear() { notes.removeAll(); save() }
}
