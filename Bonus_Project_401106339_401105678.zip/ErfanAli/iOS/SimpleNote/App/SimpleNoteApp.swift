import SwiftUI

@main
struct SimpleNoteApp: App {
    @StateObject private var appState = AppState()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(appState)
        }
    }
}

final class AppState: ObservableObject {
    @Published var accessToken: String? = TokenStore.shared.access
    @Published var refreshToken: String? = TokenStore.shared.refresh

    var isLoggedIn: Bool { (accessToken?.isEmpty == false) || (refreshToken?.isEmpty == false) }

    func onLogin(access: String?, refresh: String?) {
        TokenStore.shared.save(access: access, refresh: refresh)
        accessToken = access
        refreshToken = refresh
    }

    func logout() {
        TokenStore.shared.clear()
        accessToken = nil
        refreshToken = nil
    }
}

struct RootView: View {
    @EnvironmentObject var app: AppState

    var body: some View {
        if app.isLoggedIn {
            NotesScreen()
        } else {
            GettingStartedScreen()
        }
    }
}
