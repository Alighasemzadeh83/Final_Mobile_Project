import Foundation

struct TokenRequest: Codable { let username: String; let password: String }
struct TokenResponse: Codable { let access: String?; let refresh: String? }
struct RegisterRequest: Codable { let username, password, email, first_name, last_name: String }
struct RegisterResponse: Codable { let id: Int?; let username: String? }
struct RefreshRequest: Codable { let refresh: String }
struct RefreshResponse: Codable { let access: String? }
struct MessageResponse: Codable { let message: String? }
struct ChangePasswordRequest: Codable { let old_password: String; let new_password: String }
struct UserInfo: Codable { let id: Int?; let username: String?; let email: String? }

struct NoteRequest: Codable { let title: String; let description: String }
struct Note: Codable, Identifiable { let id: Int; let title, description: String; let created_at: String; let updated_at: String }
struct PaginatedNoteList: Codable { let count: Int; let next: String?; let previous: String?; let results: [Note] }

