import Foundation

enum AuthAPI {
    static func login(username: String, password: String) async throws -> TokenResponse {
        let body = try JSONEncoder().encode(TokenRequest(username: username, password: password))
        let (data, resp) = try await HTTPClient.request("/api/auth/token/", method: "POST", body: body, authorized: false)
        guard (200..<300).contains(resp.statusCode) else { throw APIError.http(resp.statusCode) }
        return try HTTPClient.decode(data)
    }

    static func register(_ r: RegisterRequest) async throws -> RegisterResponse {
        let body = try JSONEncoder().encode(r)
        let (data, resp) = try await HTTPClient.request("/api/auth/register/", method: "POST", body: body, authorized: false)
        guard (200..<300).contains(resp.statusCode) else { throw APIError.http(resp.statusCode) }
        return try HTTPClient.decode(data)
    }

    static func refreshToken(refresh: String) async throws -> String? {
        let body = try JSONEncoder().encode(RefreshRequest(refresh: refresh))
        let (data, resp) = try await HTTPClient.request("/api/auth/token/refresh/", method: "POST", body: body, authorized: false)
        guard (200..<300).contains(resp.statusCode) else { throw APIError.http(resp.statusCode) }
        let r: RefreshResponse = try HTTPClient.decode(data)
        return r.access
    }

    static func userInfo() async throws -> UserInfo {
        let (data, resp) = try await HTTPClient.request("/api/auth/userinfo/")
        guard (200..<300).contains(resp.statusCode) else { throw APIError.http(resp.statusCode) }
        return try HTTPClient.decode(data)
    }

    static func changePassword(old: String, new: String) async throws -> MessageResponse {
        let body = try JSONEncoder().encode(ChangePasswordRequest(old_password: old, new_password: new))
        let (data, resp) = try await HTTPClient.request("/api/auth/change-password/", method: "POST", body: body)
        guard (200..<300).contains(resp.statusCode) else { throw APIError.http(resp.statusCode) }
        return try HTTPClient.decode(data)
    }
}

enum NotesAPI {
    static func list(page: Int? = nil, pageSize: Int? = nil) async throws -> PaginatedNoteList {
        var q: [URLQueryItem] = []
        if let page { q.append(URLQueryItem(name: "page", value: String(page))) }
        if let pageSize { q.append(URLQueryItem(name: "page_size", value: String(pageSize))) }
        let (data, resp) = try await HTTPClient.request("/api/notes/", query: q)
        guard (200..<300).contains(resp.statusCode) else { throw APIError.http(resp.statusCode) }
        return try HTTPClient.decode(data)
    }

    static func filter(title: String? = nil, description: String? = nil, page: Int? = nil, pageSize: Int? = nil) async throws -> PaginatedNoteList {
        var q: [URLQueryItem] = []
        if let title { q.append(URLQueryItem(name: "title", value: title)) }
        if let description { q.append(URLQueryItem(name: "description", value: description)) }
        if let page { q.append(URLQueryItem(name: "page", value: String(page))) }
        if let pageSize { q.append(URLQueryItem(name: "page_size", value: String(pageSize))) }
        let (data, resp) = try await HTTPClient.request("/api/notes/filter", query: q)
        guard (200..<300).contains(resp.statusCode) else { throw APIError.http(resp.statusCode) }
        return try HTTPClient.decode(data)
    }

    static func retrieve(id: Int) async throws -> Note {
        let (data, resp) = try await HTTPClient.request("/api/notes/\(id)/")
        guard (200..<300).contains(resp.statusCode) else { throw APIError.http(resp.statusCode) }
        return try HTTPClient.decode(data)
    }

    static func create(_ r: NoteRequest) async throws -> Note {
        let body = try JSONEncoder().encode(r)
        let (data, resp) = try await HTTPClient.request("/api/notes/", method: "POST", body: body)
        guard (200..<300).contains(resp.statusCode) else { throw APIError.http(resp.statusCode) }
        return try HTTPClient.decode(data)
    }

    static func update(id: Int, _ r: NoteRequest) async throws -> Note {
        let body = try JSONEncoder().encode(r)
        let (data, resp) = try await HTTPClient.request("/api/notes/\(id)/", method: "PUT", body: body)
        guard (200..<300).contains(resp.statusCode) else { throw APIError.http(resp.statusCode) }
        return try HTTPClient.decode(data)
    }

    static func delete(id: Int) async throws {
        let (_, resp) = try await HTTPClient.request("/api/notes/\(id)/", method: "DELETE")
        guard (200..<300).contains(resp.statusCode) else { throw APIError.http(resp.statusCode) }
    }
}
