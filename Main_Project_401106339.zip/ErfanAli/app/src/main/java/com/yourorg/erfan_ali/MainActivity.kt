package com.yourorg.erfan_ali
import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.material3.CardDefaults
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Delete
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.yourorg.erfan_ali.ui.theme.ErfanAliTheme
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.layout.BoxWithConstraints
import kotlin.math.abs
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import okhttp3.Authenticator
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import okhttp3.Route
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import org.json.JSONObject
import retrofit2.http.DELETE
import retrofit2.http.PATCH
import retrofit2.http.PUT
import retrofit2.http.Path
import retrofit2.http.Query
import com.google.gson.annotations.SerializedName
import androidx.compose.ui.text.input.PasswordVisualTransformation
import kotlinx.coroutines.flow.Flow
import com.yourorg.erfan_ali.data.db.DatabaseProvider
import com.yourorg.erfan_ali.data.db.NoteDao
import com.yourorg.erfan_ali.data.db.NoteEntity
import com.yourorg.erfan_ali.data.guest.GuestDatabaseProvider
import com.yourorg.erfan_ali.data.guest.GuestNoteDao
import com.yourorg.erfan_ali.data.guest.GuestNoteRepository
import com.yourorg.erfan_ali.data.guest.GuestNoteEntity


private const val PREFS_NAME = "simple_note_prefs"
private const val KEY_ACCESS = "access_token"
private const val KEY_REFRESH = "refresh_token"



data class TokenRequest(val username: String, val password: String)
data class TokenResponse(val access: String?, val refresh: String?)
data class RegisterRequest(
    val username: String,
    val password: String,
    val email: String,
    val first_name: String,
    val last_name: String
)
data class RegisterResponse(val id: Int?, val username: String?)
data class RefreshRequest(val refresh: String)
data class RefreshResponse(val access: String?)
data class MessageResponse(val message: String?)
data class ChangePasswordRequest(val old_password: String, val new_password: String)

data class UserInfo(val id: Int?, val username: String?, val email: String? = null)

interface AuthService {
    @POST("/api/auth/token/")
    suspend fun obtainToken(@Body body: TokenRequest): TokenResponse

    @POST("/api/auth/register/")
    suspend fun register(@Body body: RegisterRequest): RegisterResponse

    @POST("/api/auth/token/refresh/")
    suspend fun refreshToken(@Body body: RefreshRequest): RefreshResponse

    @GET("/api/auth/userinfo/")
    suspend fun userInfo(): UserInfo

    @POST("/api/auth/change-password/")
    suspend fun changePassword(@Body body: ChangePasswordRequest): MessageResponse
}

object ApiClient {
    private const val BASE_URL = "http://10.0.2.2:8000/" // emulator -> localhost http://10.105.205.44:8000
    private var retrofit: Retrofit? = null
    lateinit var authService: AuthService
        private set

    fun init(context: Context) {
        
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }

       
        val tokenProvider: () -> String? = {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            prefs.getString(KEY_ACCESS, null)
        }

        val authInterceptor = Interceptor { chain ->
            val original = chain.request()
            val builder = original.newBuilder()
            val token = tokenProvider()
            if (!token.isNullOrEmpty()) {
                builder.addHeader("Authorization", "Bearer $token")
            }
            chain.proceed(builder.build())
        }

        
        val tokenAuthenticator = Authenticator { _: Route?, response: Response ->
            
            var prior = response.priorResponse
            var tryCount = 1
            while (prior != null) { tryCount++; prior = prior.priorResponse }
            if (tryCount >= 2) return@Authenticator null

            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val refresh = prefs.getString(KEY_REFRESH, null) ?: return@Authenticator null

            try {
                val json = "{" + "\"refresh\":\"" + refresh + "\"}"
                val media = "application/json".toMediaType()
                val body = json.toRequestBody(media)
                // از کلاینت ساده بدون authenticator استفاده می‌کنیم
                val bareClient = OkHttpClient.Builder().addInterceptor(logging).build()
                val req = okhttp3.Request.Builder()
                    .url(BASE_URL + "api/auth/token/refresh/")
                    .post(body)
                    .build()
                val resp = bareClient.newCall(req).execute()
                if (!resp.isSuccessful) return@Authenticator null
                val content = resp.body?.string() ?: return@Authenticator null
                val obj = org.json.JSONObject(content)
                val newAccess = obj.optString("access", null) ?: return@Authenticator null
                prefs.edit().putString(KEY_ACCESS, newAccess).apply()
                response.request.newBuilder()
                    .header("Authorization", "Bearer $newAccess")
                    .build()
            } catch (_: Exception) {
                null
            }
        }

        val client = OkHttpClient.Builder()
            .addInterceptor(authInterceptor)
            .authenticator(tokenAuthenticator)
            .addInterceptor(logging)
            .build()


        retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        authService = retrofit!!.create(AuthService::class.java)
        NoteClient.init(retrofit!!)
    }
}

class AuthRepository(private val context: Context) {
    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    suspend fun login(username: String, password: String): TokenResponse {
        return ApiClient.authService.obtainToken(TokenRequest(username, password))
    }

    suspend fun register(username: String, password: String, email: String, firstName: String, lastName: String): RegisterResponse {
        return ApiClient.authService.register(RegisterRequest(username, password , email , firstName , lastName))
    }

    fun saveTokens(access: String?, refresh: String?) {
        prefs.edit().putString(KEY_ACCESS, access).putString(KEY_REFRESH, refresh).apply()
    }

    fun getAccessToken(): String? = prefs.getString(KEY_ACCESS, null)
    fun getRefreshToken(): String? = prefs.getString(KEY_REFRESH, null)

    fun clearTokens() {
        prefs.edit().remove(KEY_ACCESS).remove(KEY_REFRESH).apply()
    }

    suspend fun refreshAccessToken(): String? {
        val refresh = getRefreshToken() ?: return null
        val resp = ApiClient.authService.refreshToken(RefreshRequest(refresh))
        // save new access (keep old refresh)
        saveTokens(resp.access, refresh)
        return resp.access
    }

    suspend fun fetchUserInfo(): UserInfo {
        return ApiClient.authService.userInfo()
    }

    suspend fun changePassword(oldPass: String, newPass: String): MessageResponse {
        return ApiClient.authService.changePassword(ChangePasswordRequest(oldPass, newPass))
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ApiClient.init(applicationContext)

        enableEdgeToEdge()
        setContent {
            ErfanAliTheme {
                val navController = rememberNavController()
                NavHost(navController = navController, startDestination = "splash") {
                    composable("splash") { SplashRoute(navController) }

                    composable("getting_started") { GettingStartedScreen(navController) }
                    composable("login") { LoginScreen(navController) }
                    composable("register") { RegisterScreen(navController) }
                    composable("profile") { ProfileScreen(navController) }
                    composable("change_password") { ChangePasswordScreen(navController) }

                    composable("notes") { NoteListScreen(navController) }
                    composable("note_detail/{noteId}") { backStackEntry ->
                        val id = backStackEntry.arguments?.getString("noteId")?.toInt() ?: 0
                        NoteDetailScreen(navController, id)
                    }

                    composable("note_edit") { NoteEditScreen(navController, null) }
                    composable("note_edit/{noteId}") { backStackEntry ->
                        val id = backStackEntry.arguments?.getString("noteId")?.toInt()
                        NoteEditScreen(navController, id)
                    }


                }
            }
        }
    }
}


@Composable
fun SplashRoute(navController: NavHostController) {
    val context = LocalContext.current
    LaunchedEffect(Unit) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val hasAccess = !prefs.getString(KEY_ACCESS, null).isNullOrBlank()
        val hasRefresh = !prefs.getString(KEY_REFRESH, null).isNullOrBlank()
        val target = if (hasAccess || hasRefresh) "notes" else "getting_started"
        navController.navigate(target) {
            popUpTo("splash") { inclusive = true }
            launchSingleTop = true
        }
    }
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator()
    }
}

@Composable
fun GettingStartedScreen(navController: NavHostController) {
    Scaffold { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(20.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Text(text = "Welcome to SimpleNote!", style = MaterialTheme.typography.headlineMedium)
            Spacer(modifier = Modifier.height(24.dp))
            Button(onClick = { navController.navigate("login") }, modifier = Modifier.fillMaxWidth()) { Text("Getting Started") }
            Spacer(modifier = Modifier.height(12.dp))
            OutlinedButton(onClick = { navController.navigate("notes") }, modifier = Modifier.fillMaxWidth()) { Text("Continue as Guest") }
        }
    }
}

@Composable
fun LoginScreen(navController: NavHostController) {
    val context = LocalContext.current
    val repo = remember { AuthRepository(context) }
    var username by remember { mutableStateOf("erfan") }
    var password by remember { mutableStateOf("1234qwer@") }
    var message by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Scaffold { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Text(text = "Login", style = MaterialTheme.typography.headlineMedium)
            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(value = username, onValueChange = { username = it }, label = { Text("Username") }, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("Password") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password))
            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                    scope.launch {
                        isLoading = true
                        message = ""
                        try {
                            val resp = repo.login(username.trim(), password)

                            repo.saveTokens(resp.access, resp.refresh)
                            message = "Login successful."

                            try {
                                val guestDao = GuestDatabaseProvider.get(context).guestNoteDao()
                                val toSync = guestDao.getAll()
                                if (toSync.isNotEmpty()) {
                                    val noteDao = DatabaseProvider.get(context).noteDao()
                                    val remoteRepo = NoteRepository(noteDao)
                                    toSync.forEach { g ->
                                        remoteRepo.createNote(NoteRequest(g.title, g.description))
                                    }
                                    guestDao.clear()
                                }
                            } catch (_: Exception) {}

                            navController.navigate("notes") {
                                popUpTo("login") { inclusive = true } // حذف login از backstack
                            }
                        } catch (e: Exception) {
                            message = "Login failed: ${e.localizedMessage ?: e.message}"
                        } finally {
                            isLoading = false
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = !isLoading
            ) {
                if (isLoading) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Logging in...")
                } else {
                    Text("Login")
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Register if not yet",
                modifier = Modifier
                    .clickable { navController.navigate("register") }
                    .padding(8.dp),
                color = MaterialTheme.colorScheme.primary,
                style = MaterialTheme.typography.bodyMedium,
                textDecoration = TextDecoration.Underline
            )

            if (message.isNotEmpty()) {
                Spacer(modifier = Modifier.height(12.dp))
                Text(message)
            }
        }
    }
}




@Composable
fun ErrorDialog(
    message: String,
    onDismiss: () -> Unit,
    onCopy: (() -> Unit)? = null
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Error") },
        text = { Text(message) },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("OK")
            }
        },
        dismissButton = {
            if (onCopy != null) {
                TextButton(onClick = onCopy) {
                    Text("Copy")
                }
            }
        }
    )
}

@Composable
fun RegisterScreen(navController: NavHostController) {
    val context = LocalContext.current
    val repo = remember { AuthRepository(context) }

    var username by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var firstName by remember { mutableStateOf("") }
    var lastName by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }

    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun parseError(json: String): String {
        return try {
            val obj = JSONObject(json)
            val builder = StringBuilder()
            obj.keys().forEach { key ->
                val arr = obj.getJSONArray(key)
                for (i in 0 until arr.length()) {
                    builder.append("$key: ${arr.getString(i)}\n")
                }
            }
            builder.toString().trim()
        } catch (e: Exception) {
            json
        }
    }

    Scaffold { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Text(text = "Register", style = MaterialTheme.typography.headlineMedium)
            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(value = username, onValueChange = { username = it }, label = { Text("Username") }, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email))
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(value = firstName, onValueChange = { firstName = it }, label = { Text("First Name") }, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(value = lastName, onValueChange = { lastName = it }, label = { Text("Last Name") }, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("Password") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password))
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(value = confirmPassword, onValueChange = { confirmPassword = it }, label = { Text("Confirm Password") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password))
            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                    scope.launch {
                        if (password != confirmPassword) {
                            errorMessage = "Passwords do not match."
                            return@launch
                        }
                        if (username.isBlank() || email.isBlank() || firstName.isBlank() || lastName.isBlank() || password.isBlank()) {
                            errorMessage = "Please fill all fields."
                            return@launch
                        }

                        isLoading = true
                        try {
                            repo.register(username.trim(), password, email.trim(), firstName.trim(), lastName.trim())
                            navController.navigate("login")
                        } catch (e: retrofit2.HttpException) {
                            val body = e.response()?.errorBody()?.string()
                            errorMessage = body?.let { parseError(it) } ?: "Unknown error"
                        } catch (e: Exception) {
                            errorMessage = "Register failed: ${e.localizedMessage ?: e.message}"
                        } finally {
                            isLoading = false
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = !isLoading
            ) {
                if (isLoading) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Registering...")
                } else {
                    Text("Register")
                }
            }
        }
    }

    errorMessage?.let { msg ->
        ErrorDialog(
            message = msg,
            onDismiss = { errorMessage = null },
            onCopy = {
                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                val clip = android.content.ClipData.newPlainText("Error", msg)
                clipboard.setPrimaryClip(clip)
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(navController: NavHostController) {
    val context = LocalContext.current
    val repo = remember { AuthRepository(context) }
    val scope = rememberCoroutineScope()
    var user by remember { mutableStateOf<UserInfo?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }


    var oldPass by remember { mutableStateOf("") }
    var newPass by remember { mutableStateOf("") }
    var confirmPass by remember { mutableStateOf("") }
    var showLogoutConfirm by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        loading = true
        try {
            user = repo.fetchUserInfo()
        } catch (e: Exception) {
            error = e.localizedMessage ?: e.message ?: "Unknown error"
        } finally {
            loading = false
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Profile") },
                navigationIcon = {

                    TextButton(onClick = { navController.popBackStack() }) {
                        Text("<-", fontSize = 28.sp)
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .padding(16.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.Top
        ) {
            if (loading) {
                CircularProgressIndicator()
            } else if (error != null) {
                Text("Error: $error")
            } else {

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.size(56.dp)
                    ) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            val label = (user?.email ?: user?.username ?: "U").firstOrNull()?.uppercase() ?: "U"
                            Text(label, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        }
                    }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(user?.username ?: "-", style = MaterialTheme.typography.titleMedium)
                        Text(user?.email ?: "-", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
                Text("APP SETTINGS", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium)
                Spacer(modifier = Modifier.height(8.dp))


                ListItem(
                    headlineContent = { Text("Change Password") },
                    trailingContent = { Text(">", color = MaterialTheme.colorScheme.onSurfaceVariant) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { navController.navigate("change_password") }
                )

                Divider()


                ListItem(
                    headlineContent = { Text("Log Out", color = MaterialTheme.colorScheme.error) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showLogoutConfirm = true }
                )

                if (showLogoutConfirm) {
                    AlertDialog(
                        onDismissRequest = { showLogoutConfirm = false },
                        title = { Text("Log Out") },
                        text = { Text("Are you sure you want to log out from the application?") },
                        confirmButton = {
                            TextButton(onClick = {
                                showLogoutConfirm = false

                                repo.clearTokens()
                                navController.navigate("login") {
                                    popUpTo("getting_started") { inclusive = false }
                                    launchSingleTop = true
                                }
                            }) { Text("Yes") }
                        },
                        dismissButton = {
                            TextButton(onClick = { showLogoutConfirm = false }) { Text("Cancel") }
                        }
                    )
                }
            }
        }
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChangePasswordScreen(navController: NavHostController) {
    val context = LocalContext.current
    val repo = remember { AuthRepository(context) }
    val scope = rememberCoroutineScope()
    var oldPass by remember { mutableStateOf("") }
    var newPass by remember { mutableStateOf("") }
    var confirmPass by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Change Password") },
                navigationIcon = {
                    TextButton(onClick = { navController.popBackStack() }) { Text("<-", fontSize = 28.sp) }
                }
            )
        }
    ) { innerPadding ->
        Column(Modifier.padding(innerPadding).padding(16.dp)) {
            Text("Please input your current password first", color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = oldPass,
                onValueChange = { oldPass = it },
                label = { Text("Current Password") },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                visualTransformation = PasswordVisualTransformation()
            )
            Spacer(Modifier.height(12.dp))
            Text("Now, create your new password", color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = newPass,
                onValueChange = { newPass = it },
                label = { Text("New Password") },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                visualTransformation = PasswordVisualTransformation()
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = confirmPass,
                onValueChange = { confirmPass = it },
                label = { Text("Retype New Password") },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                visualTransformation = PasswordVisualTransformation()
            )
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = {
                    msg = null
                    if (oldPass.isBlank() || newPass.isBlank() || confirmPass.isBlank()) {
                        msg = "Please fill all fields"
                        return@Button
                    }
                    if (newPass != confirmPass) {
                        msg = "New password and confirm do not match"
                        return@Button
                    }
                    loading = true
                    scope.launch {
                        try {
                            val resp = repo.changePassword(oldPass, newPass)
                            msg = resp.message ?: "Password changed"
                            oldPass = ""; newPass = ""; confirmPass = ""
                        } catch (e: Exception) {
                            msg = e.localizedMessage ?: e.message ?: "Failed to change password"
                        } finally { loading = false }
                    }
                },
                enabled = !loading,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (loading) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                    Text("Submitting...")
                } else {
                    Text("Submit New Password")
                }
            }

            msg?.let { Spacer(Modifier.height(8.dp)); Text(it) }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun GettingStartedPreview() {
    ErfanAliTheme {
        GettingStartedScreen(navController = rememberNavController())
    }
}

@Preview(showBackground = true)
@Composable
fun LoginPreview() {
    ErfanAliTheme {
        LoginScreen(navController = rememberNavController())
    }
}

@Preview(showBackground = true)
@Composable
fun RegisterPreview() {
    ErfanAliTheme {
        RegisterScreen(navController = rememberNavController())
    }
}



data class NoteRequest(
    val title: String,
    val description: String
)

data class Note(
    val id: Int,
    val title: String,
    val description: String,
    @SerializedName("created_at") val created: String,
    @SerializedName("updated_at") val updated: String
)

data class PaginatedNoteList(
    val count: Int,
    val next: String?,
    val previous: String?,
    val results: List<Note>
)


interface NoteService {
    @GET("/api/notes/")
    suspend fun listNotes(
        @Query("page") page: Int? = null,
        @Query("page_size") page_size: Int? = null
    ): PaginatedNoteList

    @GET("/api/notes/filter")
    suspend fun filterNotes(
        @Query("title") title: String? = null,
        @Query("description") description: String? = null,
        @Query("updated__gte") updated__gte: String? = null,
        @Query("updated__lte") updated__lte: String? = null,
        @Query("page") page: Int? = null,
        @Query("page_size") page_size: Int? = null
    ): PaginatedNoteList

    @GET("/api/notes/{id}/")
    suspend fun retrieveNote(@Path("id") id: Int): Note

    @POST("/api/notes/")
    suspend fun createNote(@Body body: NoteRequest): Note

    @PUT("/api/notes/{id}/")
    suspend fun updateNote(@Path("id") id: Int, @Body body: NoteRequest): Note

    @PATCH("/api/notes/{id}/")
    suspend fun partialUpdateNote(@Path("id") id: Int, @Body body: NoteRequest): Note

    @DELETE("/api/notes/{id}/")
    suspend fun deleteNote(@Path("id") id: Int)
}

object NoteClient {
    lateinit var noteService: NoteService
        private set

    fun init(retrofit: Retrofit) {
        noteService = retrofit.create(NoteService::class.java)
    }
}



class NoteRepository(private val dao: NoteDao) {
    private fun Note.toEntity() = NoteEntity(id, title, description, created, updated)

    suspend fun listNotes(page: Int? = null, page_size: Int? = null): PaginatedNoteList {
        val resp = NoteClient.noteService.listNotes(page, page_size)
        try { dao.upsertAll(resp.results.map { it.toEntity() }) } catch (_: Exception) {}
        return resp
    }

    suspend fun filterNotes(
        title: String? = null,
        description: String? = null,
        updated__gte: String? = null,
        updated__lte: String? = null,
        page: Int? = null,
        page_size: Int? = null
    ): PaginatedNoteList {
        val resp = NoteClient.noteService.filterNotes(title, description, updated__gte, updated__lte, page, page_size)
        try { dao.upsertAll(resp.results.map { it.toEntity() }) } catch (_: Exception) {}
        return resp
    }

    suspend fun retrieveNote(id: Int): Note {
        val n = NoteClient.noteService.retrieveNote(id)
        try { dao.upsert(n.toEntity()) } catch (_: Exception) {}
        return n
    }

    suspend fun createNote(note: NoteRequest): Note {
        val n = NoteClient.noteService.createNote(note)
        try { dao.upsert(n.toEntity()) } catch (_: Exception) {}
        return n
    }

    suspend fun updateNote(id: Int, note: NoteRequest): Note {
        val n = NoteClient.noteService.updateNote(id, note)
        try { dao.upsert(n.toEntity()) } catch (_: Exception) {}
        return n
    }

    suspend fun partialUpdateNote(id: Int, note: NoteRequest): Note {
        val n = NoteClient.noteService.partialUpdateNote(id, note)
        try { dao.upsert(n.toEntity()) } catch (_: Exception) {}
        return n
    }

    suspend fun deleteNote(id: Int) {
        NoteClient.noteService.deleteNote(id)
        try { dao.deleteById(id) } catch (_: Exception) {}
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoteListScreen(navController: NavHostController) {

    val context = LocalContext.current
    val authRepo = remember { AuthRepository(context) }
    val isGuest = remember { authRepo.getAccessToken().isNullOrBlank() && authRepo.getRefreshToken().isNullOrBlank() }

    val dao = remember { DatabaseProvider.get(context).noteDao() }
    val repo = remember { NoteRepository(dao) }
    val guestDao = remember { GuestDatabaseProvider.get(context).guestNoteDao() }
    val guestRepo = remember { GuestNoteRepository(guestDao) }


    var headerUser by remember { mutableStateOf<UserInfo?>(null) }
    LaunchedEffect(isGuest) {
        if (!isGuest) {
            try { headerUser = authRepo.fetchUserInfo() } catch (_: Exception) {}
        }
    }

    var notes by remember { mutableStateOf(listOf<Note>()) }
    var currentPage by remember { mutableStateOf(1) }
    var totalCount by remember { mutableStateOf(0) }
    var isLoading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()


    var search by remember { mutableStateOf("") }
    val notesFlow: Flow<List<NoteEntity>> = remember(search) {
        if (search.isBlank()) dao.observeAll() else dao.observeByLike("%$search%")
    }
    val notesLocal by notesFlow.collectAsState(initial = emptyList())

    val guestFlow: Flow<List<GuestNoteEntity>> = remember(search) {
        if (search.isBlank()) guestDao.observeAll() else guestDao.observeByLike("%$search%")
    }
    val notesGuest by guestFlow.collectAsState(initial = emptyList())



    var isSearching by remember { mutableStateOf(false) }
    var searchResults by remember { mutableStateOf(listOf<Note>()) }

    fun performSearch() {
        if (search.isBlank()) {
            isSearching = false
            return
        }
        if (isGuest) {

            isSearching = false
        } else {
            isSearching = true
            scope.launch {
                try {
                    val resp = repo.filterNotes(title = search, description = search, page = 1, page_size = 40)
                    searchResults = resp.results
                } catch (_: Exception) {}
            }
        }
    }

    LaunchedEffect(search) {

        delay(350)
        performSearch()
    }


    fun loadNotes(page: Int) {
        scope.launch {
            isLoading = true
            try {
                val resp = repo.listNotes(page = page, page_size = 20)
                if (page == 1) notes = resp.results else notes = notes + resp.results
                totalCount = resp.count
                currentPage = page
            } catch (e: Exception) {

            } finally {
                isLoading = false
            }
        }
    }

    LaunchedEffect(isGuest) { if (!isGuest) loadNotes(1) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Notes") },
                actions = {
                    if (!isGuest) {

                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier
                                .padding(end = 8.dp)
                                .size(40.dp)
                                .clickable { navController.navigate("profile") }
                        ) {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                val label = (headerUser?.email ?: headerUser?.username ?: "U").take(2).uppercase()
                                Text(label, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            }
                        }

                    }
                }
            )
        },

        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = true,
                    onClick = { /* already here */ },
                    icon = { Icon(Icons.Filled.Home, contentDescription = "Home") },
                    label = { Text("Home") }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = { navController.navigate("profile") },
                    icon = { Icon(Icons.Filled.Settings, contentDescription = "Settings") },
                    label = { Text("Settings") }
                )
            }
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { navController.navigate("note_edit") }) {
                Text("+")
            }
        },
        floatingActionButtonPosition = FabPosition.Center
    ) { innerPadding ->
        Column(modifier = Modifier.padding(innerPadding).fillMaxSize()) {

            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                label = { Text("Search notes") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { performSearch() }),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
            )

            val gridState = rememberLazyGridState()
            Box(Modifier.fillMaxSize()) {
            LazyVerticalGrid(state = gridState, columns = GridCells.Fixed(2), modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(8.dp)) {
                if (!isGuest && isSearching) {
                    items(searchResults) { note ->
                        Card(
                            modifier = Modifier
                                .padding(8.dp)
                                .clickable { navController.navigate("note_detail/${note.id}") },
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = run {
                                val colors = listOf(
                                    Color(0xFFFFF9C4), Color(0xFFFFECB3), Color(0xFFFFF3E0),
                                    Color(0xFFE1F5FE), Color(0xFFE8F5E9)
                                )
                                colors[abs(note.id) % colors.size]
                            })
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(note.title, style = MaterialTheme.typography.titleMedium)
                                Text(note.description, style = MaterialTheme.typography.bodyMedium)
                                // start (ali added): افزودن نمایش تاریخ ایجاد علاوه بر آخرین ویرایش
                                Text("Created: ${note.created}", style = MaterialTheme.typography.bodySmall)
                                Text("Updated: ${note.updated}", style = MaterialTheme.typography.bodySmall)

                            }
                        }
                    }
                } else if (isGuest) {
                    items(notesGuest) { note ->
                        Card(
                            modifier = Modifier
                                .padding(8.dp)
                                .clickable { navController.navigate("note_detail/${note.id}") },
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = run {
                                val colors = listOf(
                                    Color(0xFFFFF9C4), Color(0xFFFFECB3), Color(0xFFFFF3E0),
                                    Color(0xFFE1F5FE), Color(0xFFE8F5E9)
                                )
                                colors[abs(note.id) % colors.size]
                            })
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(note.title, style = MaterialTheme.typography.titleMedium)
                                Text(note.description, style = MaterialTheme.typography.bodyMedium)
                                Text("Created: ${java.util.Date(note.created)}", style = MaterialTheme.typography.bodySmall)
                                Text("Updated: ${java.util.Date(note.updated)}", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                } else {
                    items(notesLocal) { note ->
                        Card(
                            modifier = Modifier
                                .padding(8.dp)
                                .clickable { navController.navigate("note_detail/${note.id}") },
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = run {
                                val colors = listOf(
                                    Color(0xFFFFF9C4), Color(0xFFFFECB3), Color(0xFFFFF3E0),
                                    Color(0xFFE1F5FE), Color(0xFFE8F5E9)
                                )
                                colors[abs(note.id) % colors.size]
                            })
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(note.title, style = MaterialTheme.typography.titleMedium)
                                Text(note.description, style = MaterialTheme.typography.bodyMedium)

                                Text("Created: ${note.created}", style = MaterialTheme.typography.bodySmall)
                                Text("Updated: ${note.updated}", style = MaterialTheme.typography.bodySmall)

                            }
                        }
                    }
                }


                item(span = { GridItemSpan(maxLineSpan) }) {
                    if (isLoading) {
                        Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator()
                        }
                    } else if (!isGuest && !isSearching && notes.size < totalCount) {
                        Button(onClick = { loadNotes(currentPage + 1) }, modifier = Modifier.fillMaxWidth()) {
                            Text("Load more")
                        }
                    }
                }
            }


            val totalItems = when {
                !isGuest && isSearching -> searchResults.size
                isGuest -> notesGuest.size
                else -> notesLocal.size
            }
            if (totalItems > 20) {
                BoxWithConstraints(Modifier.fillMaxSize()) {
                    val trackHeight = maxHeight
                    val visible = gridState.layoutInfo.visibleItemsInfo.size.coerceAtLeast(1)
                    val thumbFrac = (visible.toFloat() / totalItems.toFloat()).coerceIn(0.10f, 0.6f)
                    val thumbHeight = trackHeight * thumbFrac
                    val maxIndex = (totalItems - visible).coerceAtLeast(1)
                    val frac = (gridState.firstVisibleItemIndex.toFloat() / maxIndex.toFloat()).coerceIn(0f, 1f)
                    val offsetY = (trackHeight - thumbHeight) * frac

                    Box(
                        modifier = Modifier
                            .align(Alignment.CenterEnd)
                            .padding(end = 2.dp)
                            .width(6.dp)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(3.dp))
                            .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                    )
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(end = 2.dp)
                            .offset(y = offsetY)
                            .width(6.dp)
                            .height(thumbHeight)
                            .clip(RoundedCornerShape(3.dp))
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.6f))
                    )
                }
            }
            }

        }
    }


    LaunchedEffect(navController) {
        navController.currentBackStackEntryFlow.collect { backStackEntry ->
            if (backStackEntry.destination.route == "notes") loadNotes(1)
        }
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoteDetailScreen(navController: NavHostController, noteId: Int) {
    val context = LocalContext.current

    val authRepo = remember { AuthRepository(context) }
    val isGuest = remember { authRepo.getAccessToken().isNullOrBlank() && authRepo.getRefreshToken().isNullOrBlank() }
    val dao = remember { DatabaseProvider.get(context).noteDao() }
    val repo = remember { NoteRepository(dao) }
    val guestRepo = remember { GuestNoteRepository(GuestDatabaseProvider.get(context).guestNoteDao()) }

    var note by remember { mutableStateOf<Note?>(null) }
    val scope = rememberCoroutineScope()
    var isLoading by remember { mutableStateOf(false) }


    var showDeleteSheet by remember { mutableStateOf(false) }



    LaunchedEffect(noteId, isGuest) {
        scope.launch {
            isLoading = true
            try {
                note = if (isGuest) guestRepo.retrieveNote(noteId) else repo.retrieveNote(noteId)
            } catch (_: Exception) {}
            finally { isLoading = false }
        }
    }


    var titleText by remember { mutableStateOf("") }
    var descText by remember { mutableStateOf("") }
    var saving by remember { mutableStateOf(false) }
    var saveMsg by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(note) {
        note?.let { n ->
            titleText = n.title
            descText = n.description
        }
    }


    Scaffold(
        topBar = {

            TopAppBar(
                title = { Text(note?.title ?: "Loading...") },
                navigationIcon = {
                    TextButton(onClick = { navController.popBackStack() }) { Text("<-", fontSize = 28.sp) }
                },
                actions = {
                    val dirty = note != null && (titleText != note!!.title || descText != note!!.description)
                    if (dirty) {
                        TextButton(enabled = !saving, onClick = {
                            val current = note ?: return@TextButton
                            saving = true
                            saveMsg = null
                            scope.launch {
                                try {
                                    val updated = if (isGuest)
                                        guestRepo.updateNote(current.id, NoteRequest(titleText, descText))
                                    else
                                        repo.updateNote(current.id, NoteRequest(titleText, descText))
                                    note = updated
                                    saveMsg = "Saved"
                                } catch (e: Exception) {
                                    saveMsg = e.localizedMessage ?: e.message ?: "Save failed"
                                } finally { saving = false }
                            }
                        }) { Text(if (saving) "Saving..." else "Save") }
                    }
                }
            )


        },
        bottomBar = {

            Row(modifier = Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {

                    Text("Created on ${note?.created ?: "-"}", style = MaterialTheme.typography.bodySmall)
                    Text("Last edited on ${note?.updated ?: "-"}", style = MaterialTheme.typography.bodySmall)

                }
                FilledIconButton(onClick = { showDeleteSheet = true }) {
                    Icon(Icons.Filled.Delete, contentDescription = "Delete")
                }
            }
        }
    ) { innerPadding ->
        Column(modifier = Modifier.padding(innerPadding).padding(16.dp)) {
            if (isLoading) {
                CircularProgressIndicator()
            } else if (note != null) {

                OutlinedTextField(
                    value = titleText,
                    onValueChange = { titleText = it },
                    label = { Text("Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = descText,
                    onValueChange = { descText = it },
                    label = { Text("Description") },
                    placeholder = { Text("Feel Free to Write Here...") },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 200.dp),
                    minLines = 8,
                    maxLines = 20
                )
                saveMsg?.let { Spacer(Modifier.height(8.dp)); Text(it) }

            }
        }

        if (showDeleteSheet) {
            ModalBottomSheet(onDismissRequest = { showDeleteSheet = false }) {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Text("Want to Delete this Note?")
                    Spacer(Modifier.height(12.dp))
                    Button(colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        onClick = {
                    val id = note?.id ?: return@Button
                    scope.launch {
                        if (isGuest) guestRepo.deleteNote(id) else repo.deleteNote(id)
                        showDeleteSheet = false
                        navController.popBackStack()
                    }
                }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Filled.Delete, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Delete Note")
                    }
                    Spacer(Modifier.height(8.dp))
                }
            }
        }
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoteEditScreen(navController: NavHostController, noteId: Int? = null) {

    val context = LocalContext.current
    val authRepo = remember { AuthRepository(context) }
    val isGuest = remember { authRepo.getAccessToken().isNullOrBlank() && authRepo.getRefreshToken().isNullOrBlank() }
    val dao = remember { DatabaseProvider.get(context).noteDao() }
    val repo = remember { NoteRepository(dao) }
    val guestRepo = remember { GuestNoteRepository(GuestDatabaseProvider.get(context).guestNoteDao()) }

    val scope = rememberCoroutineScope()
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    val isNew = noteId == null

    LaunchedEffect(noteId) {
        if (!isNew) {
            isLoading = true
            try {
                val n = if (isGuest) guestRepo.retrieveNote(noteId!!) else repo.retrieveNote(noteId!!)
                title = n.title; description = n.description
            } catch (_: Exception) {} finally { isLoading = false }
        }
    }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text(if (isNew) "Create Note" else "Edit Note") },
            navigationIcon = { TextButton(onClick = { navController.popBackStack() }) { Text("<-", fontSize = 28.sp) } }
        )
    }) { innerPadding ->
        Column(modifier = Modifier.padding(innerPadding).padding(16.dp)) {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Title") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Description") },
                placeholder = { Text("Feel Free to Write Here...") },
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 200.dp),
                minLines = 8,
                maxLines = 20
            )

            Spacer(modifier = Modifier.height(16.dp))
            Button(onClick = {
                scope.launch {
                    isLoading = true
                    try {
                        if (isNew) {
                            if (isGuest) guestRepo.createNote(NoteRequest(title, description)) else repo.createNote(NoteRequest(title, description))
                        } else {
                            if (isGuest) guestRepo.updateNote(noteId!!, NoteRequest(title, description)) else repo.updateNote(noteId!!, NoteRequest(title, description))
                        }
                        navController.popBackStack()
                    } catch (_: Exception) {} finally { isLoading = false }
                }
            }, modifier = Modifier.fillMaxWidth(), enabled = !isLoading) { Text(if (isNew) "Create" else "Save") }
        }
    }
}

